<?php

use App\Http\Controllers\CususerController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register', [CususerController::class, 'register'])->name('register');

Route::post('registeruser', [CususerController::class, 'registeruser'])->name('registeruser');

Route::get('/login', [CususerController::class, 'login'])->name('login');

Route::post('logincheck', [CususerController::class, 'logincheck'])->name('logincheck');

Route::get('index', [CususerController::class, 'index'])->name('index');

Route::get('addstud', [CususerController::class, 'addstud'])->name('addstud');

Route::post('addstudcheck', [CususerController::class, 'addstudcheck'])->name('addstudcheck');

Route::get('viewstudent', [CususerController::class, 'viewstudent'])->name('viewstudent');

Route::get('updatestud/{id?}', [CususerController::class, 'updatestud'])->name('updatestud');

Route::any('updstd/{id?}', [CususerController::class, 'updstd'])->name('updstd');

Route::any('deletestud/{id?}', [CususerController::class, 'deletestud'])->name('deletestud');
