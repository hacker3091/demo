<?php

namespace App\Http\Controllers;

use App\Models\cususer;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CususerController extends Controller
{
    public function register()
    {
        return view('register');
    }

    public function registeruser(Request $r)
    {
        // return $r->name;
        User::create($r->all());
        return redirect('login');
    }

    public function login()
    {
        return view('login');
    }

    public function logincheck(Request $r)
    {
        $user = $r->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);
        if(Auth::attempt($user))
        {
            return redirect('index');
            // return "LOGIN SUCCESSSFULL";
        }
    }

    public function index()
    {
        return view('index');
    }

    public function addstud()
    {
        return view('addstud');
    }

    public function addstudcheck(Request $r)
    {
        $data = $r->validate([
            'fname' => 'required',
            'lname' => 'required',
            'email' => 'required|email',
        ]);
        // return $data;
        cususer::create($data);
        // return "Created";
        return redirect('viewstudent');
        // return $r;
    }

    public function viewstudent()
    {
        $users = cususer::all();
        return view('viewstud',['studs'=>$users]);
    }

    public function updatestud($id)
    {
        $stud = cususer::where('stud_id', $id)->first();
        return view('updatestud', ['stud' => $stud]);
    }

    public function updstd($id,Request $r)
    {

        cususer::where('stud_id', $id)->update([
            'fname' => $r->fname,
            'lname' => $r->lname,
            'email' => $r->email,
        ]);

        return redirect('viewstudent');        
    }

    public function deletestud($id)
    {
        cususer::where('stud_id', $id)->delete();
        return redirect('viewstudent');

    }
}
