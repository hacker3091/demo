<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class cususer extends Model
{
    protected $table = 'student';
    protected $primarykey = 'stud_id';
    protected $fillable = [
        'fname',
        'lname',
        'email'
    ];
}
