<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="{{route('addstudcheck')}}" method="post">
        @csrf
       Authorname : <input type="text" name="fname">
        Bookname : <input type="text" name="lname">
        Email : <input type="email" name="email">

        <input type="submit" value="Add">

    </form>
</body>
</html>