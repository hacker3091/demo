<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <th>Id</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        @foreach ($studs as $s)

            <tr>
                <td>{{$s->stud_id}}</td>
                <td>{{$s->fname}}</td>
                <td>{{$s->lname}}</td>
                <td>{{$s->email}}</td>
                <td><a href="{{route('updatestud', ['id' => $s->stud_id])}}">Edit</a> | <a href="{{route('deletestud', ['id' => $s->stud_id])}}">Delete</a></td>
            </tr>
        @endforeach
    </table>
</body>
</html>