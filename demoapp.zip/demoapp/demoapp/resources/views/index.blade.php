<h1>This is  home page</h1>


<a href="{{route('addstud')}}">ADD</a>