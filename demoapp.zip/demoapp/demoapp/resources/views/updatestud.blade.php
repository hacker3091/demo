<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form action="{{route('updstd',['id'=>$stud->stud_id])}}" method="post">
        @csrf
        First Name : <input type="text" name="fname" value="{{$stud->fname}}">
        Last Name : <input type="text" name="lname" value="{{$stud->lname}}">
        Email : <input type="email" name="email" value="{{$stud->email}}">

        <input type="submit" value="Update">

    </form>
</body>

</html>