<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form action="<?php echo e(route('logincheck')); ?>" method="post">
        <?php echo csrf_field(); ?>
        Email : <input type="text" name="email" id="">
        Password : <input type="text" name="password" id="">

        <input type="submit" value="Login">
    </form>
</body>

</html><?php /**PATH C:\Users\Meet\Desktop\Sem-2\demoapp\resources\views/login.blade.php ENDPATH**/ ?>