<h1>This is  home page</h1>


<a href="<?php echo e(route('addstud')); ?>">ADD</a><?php /**PATH C:\xampp\htdocs\demoapp\demoapp\resources\views/index.blade.php ENDPATH**/ ?>