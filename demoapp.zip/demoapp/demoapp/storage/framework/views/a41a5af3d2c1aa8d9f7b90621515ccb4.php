<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form action="<?php echo e(route('updstd',['id'=>$stud->stud_id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        First Name : <input type="text" name="fname" value="<?php echo e($stud->fname); ?>">
        Last Name : <input type="text" name="lname" value="<?php echo e($stud->lname); ?>">
        Email : <input type="email" name="email" value="<?php echo e($stud->email); ?>">

        <input type="submit" value="Update">

    </form>
</body>

</html><?php /**PATH C:\Users\Meet\Desktop\Sem-2\demoapp\resources\views/updatestud.blade.php ENDPATH**/ ?>