<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <th>Id</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $studs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($s->stud_id); ?></td>
                <td><?php echo e($s->fname); ?></td>
                <td><?php echo e($s->lname); ?></td>
                <td><?php echo e($s->email); ?></td>
                <td><a href="<?php echo e(route('updatestud', ['id' => $s->stud_id])); ?>">Edit</a> | <a href="<?php echo e(route('deletestud', ['id' => $s->stud_id])); ?>">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\Users\Meet\Desktop\Sem-2\demoapp\resources\views/viewstud.blade.php ENDPATH**/ ?>