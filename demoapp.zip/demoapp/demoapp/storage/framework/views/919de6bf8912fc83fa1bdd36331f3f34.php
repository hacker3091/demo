<h1>This is  home page</h1>


<a href="<?php echo e(route('addstud')); ?>">ADD</a><?php /**PATH C:\Users\Meet\Desktop\Sem-2\demoapp\resources\views/index.blade.php ENDPATH**/ ?>